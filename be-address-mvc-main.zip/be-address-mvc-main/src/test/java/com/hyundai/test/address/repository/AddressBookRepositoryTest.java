package com.hyundai.test.address.repository;

import com.hyundai.test.address.model.Customer;
import com.hyundai.test.address.model.SearchFilter;
import com.hyundai.test.address.validator.CustomerValidator;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ResponseStatusException;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AddressBookRepositoryTest {

    private AddressBookRepository repository;
    private CustomerValidator validator;
    private String testDataFile;

    @BeforeEach
    void setUp() throws IOException {
        validator = new CustomerValidator();
        repository = new AddressBookRepository(validator);

        // 테스트용 임시 파일 생성
        testDataFile = "test_address.csv";

        // 테스트 데이터 작성
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(testDataFile))) {
            writer.write("\"주소\",\"연락처\",\"이메일\",\"이름\"\n");
            writer.write("서울시,01012341234,test1@example.com,홍길동\n");
            writer.write("부산시,010-5678-1234,test2@example.com,김철수\n");
            writer.write("대구시,01098765432,test3@example.com,박영희\n");
            writer.write("인천시,011-1111-2222,invalid@test.com,최민호\n");  //invalid 011
            writer.write("서울시,01022223333,ABC,정수진\n");  // invalid 이메일
            writer.write("광주시,01012341234,duplicate@test.com,중복\n");  // 중복 전화번호
            writer.write("대전시,01033334444,test3@example.com,이메일중복\n");  // 중복 이메일
        }

        ReflectionTestUtils.setField(repository, "filePath", testDataFile);
        repository.init();
    }

    @AfterEach
    void tearDown() throws IOException {
        repository.clear();
        Files.deleteIfExists(Paths.get(testDataFile));

        // 백업 파일들도 삭제
        File dir = new File(".");
        File[] backups = dir.listFiles((d, name) -> name.startsWith("test_address_") && name.endsWith(".csv"));
        if (backups != null) {
            for (File backup : backups) {
                backup.delete();
            }
        }
    }

    @Test
    void testInitialLoading() {
        // 3개의 유효한 데이터만 로드되어야 함
        System.out.println("로드된 건수: " + repository.count());
        assertEquals(3, repository.count());

        Customer customer1 = repository.findByPhoneNumber("01012341234");
        assertNotNull(customer1);
        assertEquals("test1@example.com", customer1.getEmail());
        assertEquals("홍길동", customer1.getName());

        Customer customer2 = repository.findByPhoneNumber("010-5678-1234");
        assertNotNull(customer2);
        assertEquals("01056781234", customer2.getPhoneNumber()); // 정규화됨
    }

    @Test
    void testFindAll() {
        List<Customer> all = repository.findAll(null);
        assertEquals(3, all.size());
    }

    @Test
    void testFindByPhoneNumberFilter() {
        SearchFilter filter = new SearchFilter("01012341234", null, null, null, null, null);

        List<Customer> result = repository.findAll(filter);
        System.out.println("******* " + result.size());
        assertEquals(1, result.size());
        assertEquals("홍길동", result.get(0).getName());
    }

    @Test
    void testFindByNameLike() {
        SearchFilter filter = new SearchFilter(null, null, null, "길동", null, null);

        List<Customer> result = repository.findAll(filter);
        assertEquals(1, result.size());
        assertEquals("홍길동", result.get(0).getName());
        SearchFilter filter2 = new SearchFilter(null, null, null, "길", null, null);

        result = repository.findAll(filter);
        assertEquals(1, result.size());
        assertEquals("홍길동", result.get(0).getName());
    }

    @Test
    void testFindAllSortAsc() {
        SearchFilter filter = new SearchFilter(null, null, null, null, "NAME", "ASC");

        List<Customer> result = repository.findAll(filter);
        assertEquals(3, result.size());
        assertEquals("김철수", result.get(0).getName());
        assertEquals("박영희", result.get(1).getName());
        assertEquals("홍길동", result.get(2).getName());

        SearchFilter filterDesc = new SearchFilter(null, null, null, null, "NAME", "DESC");

        result = repository.findAll(filterDesc);
        assertEquals(3, result.size());
        assertEquals("김철수", result.get(2).getName());
        assertEquals("박영희", result.get(1).getName());
        assertEquals("홍길동", result.get(0).getName());
    }

    @Test
    void testUpdate() {
        Customer customer = repository.findByPhoneNumber("01012341234");
        customer.setName("수정된이름");
        customer.setAddress("수정된주소");

        Customer oldCustomer = repository.update(customer);
        System.out.println("변경 전: " + oldCustomer.getName() + " -> 변경 후: " + customer.getName());

        assertEquals("홍길동", oldCustomer.getName());
        assertEquals("서울시", oldCustomer.getAddress());

        Customer updated = repository.findByPhoneNumber("01012341234");
        assertEquals("수정된이름", updated.getName());
        assertEquals("수정된주소", updated.getAddress());
    }

    @Test
    void testUpdateNotFound() {
        Customer customer = new Customer("01099999999", "new@test.com", "주소", "이름");

        assertThrows(ResponseStatusException.class, () -> repository.update(customer));
    }

    @Test
    void testDeleteByPhoneNumber() {
        SearchFilter filter = new SearchFilter("01012341234", null, null, null, null, null);

        List<Customer> deleted = repository.delete(filter);
        assertEquals(1, deleted.size());
        assertEquals("홍길동", deleted.get(0).getName());

        assertEquals(2, repository.count());
    }

    @Test
    void testDeleteByNameLike() {
        SearchFilter filter = new SearchFilter(null, null, null, "김", null, null);

        List<Customer> deleted = repository.delete(filter);
        assertEquals(1, deleted.size());

        assertEquals(2, repository.count());
    }

    @Test
    void testDeleteNotFound() {
        SearchFilter filter = new SearchFilter("01099999999", null, null, null, null, null);

        assertThrows(ResponseStatusException.class, () -> repository.delete(filter));
    }

    @Test
    void testBackupAndSave() throws IOException {
        // destroy 호출 (파일 저장)
        repository.destroy();

        // 백업 파일이 생성되었는지 확인
        File dir = new File(".");
        File[] backups = dir.listFiles((d, name) -> name.startsWith("test_address_") && name.endsWith(".csv"));
        assertNotNull(backups);
        System.out.println("백업 파일: " + backups[0].getName());
        assertTrue(backups.length > 0);

        // 새 파일에 데이터가 저장되었는지 확인
        List<String> lines = Files.readAllLines(Paths.get(testDataFile));
        assertTrue(lines.size() > 1); // 헤더 + 데이터
    }

}
