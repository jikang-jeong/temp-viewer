package com.hyundai.test.address.service;

import com.hyundai.test.address.model.Customer;
import com.hyundai.test.address.model.SearchFilter;
import com.hyundai.test.address.model.UpdateResponse;
import com.hyundai.test.address.repository.AddressBookRepository;
import com.hyundai.test.address.validator.CustomerValidator;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.server.ResponseStatusException;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AddressBookServiceTest {

    @Mock
    private AddressBookRepository repository;

    @Mock
    private CustomerValidator validator;

    @InjectMocks
    private AddressBookService service;

    @Test
    void testSearchCustomers() {
        Customer c1 = new Customer("01012341234", "a@test.com", "서울", "홍길동");
        when(repository.findAll(any())).thenReturn(Arrays.asList(c1));

        SearchFilter filter = new SearchFilter(null, null, null, "홍", null, null);
        List<Customer> result = service.searchCustomers(filter);

        assertEquals(1, result.size());
        verify(repository).findAll(any());
    }

    @Test
    void testUpdateCustomer() {
        Customer input = new Customer("01012341234", "new@test.com", "부산", "김철수");
        Customer oldData = new Customer("01012341234", "old@test.com", "서울", "김철수");
        Customer newData = new Customer("01012341234", "new@test.com", "부산", "김철수");

        when(validator.isValidPhoneNumber(any())).thenReturn(true);
        when(validator.isValidEmail(any())).thenReturn(true);
        when(validator.normalizePhoneNumber(any())).thenReturn("01012341234");
        when(repository.update(any())).thenReturn(oldData);
        when(repository.findByPhoneNumber(any())).thenReturn(newData);

        UpdateResponse response = service.updateCustomer(input);

        assertNotNull(response);
        assertEquals("old@test.com", response.getBefore().getEmail());
        assertEquals("new@test.com", response.getAfter().getEmail());
    }

    @Test
    void testUpdateCustomerNoPhone() {
        Customer customer = new Customer(null, "a@test.com", "서울", "홍길동");
        try {
            System.out.println(service.updateCustomer(customer));
        } catch (Exception e) {
            System.out.println(e);
        }
        assertThrows(ResponseStatusException.class, () -> service.updateCustomer(customer));

    }

    @Test
    void testUpdateCustomerInvalidPhone() {
        Customer customer = new Customer("invalid", "a@test.com", "서울", "홍길동");
        when(validator.isValidPhoneNumber("invalid")).thenReturn(false);

        assertThrows(ResponseStatusException.class, () -> service.updateCustomer(customer));
    }

    @Test
    void testUpdateCustomerInvalidEmail() {
        Customer customer = new Customer("01012341234", "invalid", "서울", "홍길동");
        when(validator.isValidPhoneNumber("01012341234")).thenReturn(true);
        when(validator.isValidEmail("invalid")).thenReturn(false);

        assertThrows(ResponseStatusException.class, () -> service.updateCustomer(customer));
    }

    @Test
    void testDeleteCustomersNoFilter() {
        SearchFilter emptyFilter = new SearchFilter(null, null, null, null, null, null);

        assertThrows(ResponseStatusException.class, () -> service.deleteCustomers(emptyFilter));
    }

    @Test
    void testDeleteCustomers() {
        Customer c1 = new Customer("01012341234", "a@test.com", "서울", "홍길동");
        SearchFilter filter = new SearchFilter("01012341234", null, null, null, null, null);

        when(repository.delete(any())).thenReturn(Arrays.asList(c1));

        List<Customer> deleted = service.deleteCustomers(filter);

        assertEquals(1, deleted.size());
        verify(repository).delete(any());
    }
}
