package com.hyundai.test.address.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hyundai.test.address.model.Customer;
import com.hyundai.test.address.model.UpdateResponse;
import com.hyundai.test.address.service.AddressBookService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class AddressBookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AddressBookService service;

    @Test
    void testSearchCustomersAll() throws Exception {
        Customer customer1 = new Customer("01012341234", "test1@example.com", "서울시", "홍길동");
        Customer customer2 = new Customer("01056781234", "test2@example.com", "부산시", "김철수");

        when(service.searchCustomers(any())).thenReturn(Arrays.asList(customer1, customer2));

        mockMvc.perform(get("/api/customers"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].name").value("홍길동"))
                .andExpect(jsonPath("$[1].name").value("김철수"));
    }

    @Test
    void testSearchCustomersByName() throws Exception {
        Customer customer = new Customer("01012341234", "test@example.com", "서울시", "홍길동");

        when(service.searchCustomers(any())).thenReturn(Collections.singletonList(customer));

        mockMvc.perform(get("/api/customers")
                        .param("name", "홍길동"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].name").value("홍길동"));
    }

    @Test
    void testSearchCustomersWithSort() throws Exception {
        Customer customer1 = new Customer("01012341234", "test1@example.com", "서울시", "김철수");
        Customer customer2 = new Customer("01056781234", "test2@example.com", "부산시", "홍길동");

        when(service.searchCustomers(any())).thenReturn(Arrays.asList(customer1, customer2));

        mockMvc.perform(get("/api/customers")
                        .param("sortBy", "NAME")
                        .param("sortOrder", "ASC"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("김철수"))
                .andExpect(jsonPath("$[1].name").value("홍길동"));
    }

    @Test
    void testUpdateCustomer() throws Exception {
        Customer customer = new Customer("01012341234", "updated@example.com", "서울시 강남구", "홍길동");
        Customer before = new Customer("01012341234", "old@example.com", "서울시", "홍길동");

        UpdateResponse response = new UpdateResponse(before, customer);

        when(service.updateCustomer(any())).thenReturn(response);

        mockMvc.perform(put("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.before.email").value("old@example.com"))
                .andExpect(jsonPath("$.after.email").value("updated@example.com"));
    }

    @Test
    void testUpdateCustomerInvalidFormat() throws Exception {
        Customer customer = new Customer("invalid-phone", "test@example.com", "서울시", "홍길동");

        when(service.updateCustomer(any()))
                .thenThrow(new ResponseStatusException(HttpStatus.BAD_REQUEST, "전화번호 형식이 올바르지 않습니다"));

        mockMvc.perform(put("/api/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(customer)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testDeleteCustomer() throws Exception {
        Customer customer = new Customer("01012341234", "test@example.com", "서울시", "홍길동");

        when(service.deleteCustomers(any())).thenReturn(Collections.singletonList(customer));

        mockMvc.perform(delete("/api/customers")
                        .param("phoneNumber", "01012341234"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].name").value("홍길동"));
    }

    @Test
    void testDeleteCustomersByNameLike() throws Exception {
        Customer customer1 = new Customer("01012341234", "test1@example.com", "서울시", "김철수");
        Customer customer2 = new Customer("01056781234", "test2@example.com", "부산시", "김영희");

        when(service.deleteCustomers(any())).thenReturn(Arrays.asList(customer1, customer2));

        mockMvc.perform(delete("/api/customers")
                        .param("name", "김"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void testDeleteCustomersNoFilter() throws Exception {
        when(service.deleteCustomers(any()))
                .thenThrow(new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제할 조건을 지정해주세요"));

        mockMvc.perform(delete("/api/customers"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void testDeleteCustomersNotFound() throws Exception {
        when(service.deleteCustomers(any()))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "삭제할 고객을 찾을 수 없습니다"));

        mockMvc.perform(delete("/api/customers")
                        .param("phoneNumber", "01099999999"))
                .andExpect(status().isNotFound());
    }
}