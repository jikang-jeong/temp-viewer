package com.hyundai.test.address.validator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CustomerValidatorTest {

    private CustomerValidator validator;

    @BeforeEach
    void setUp() {
        validator = new CustomerValidator();
    }

    @Test
    void testPhoneNumber() {

        assertTrue(validator.isValidPhoneNumber("01012341234"));
        assertTrue(validator.isValidPhoneNumber("01099998888"));
        assertTrue(validator.isValidPhoneNumber("010-123-1234"));
        assertTrue(validator.isValidPhoneNumber("010-1234-5678"));

        assertFalse(validator.isValidPhoneNumber("01112341234"));
        assertFalse(validator.isValidPhoneNumber("031-123-1234"));
        assertFalse(validator.isValidPhoneNumber("010-12-1234"));
        assertFalse(validator.isValidPhoneNumber("010123"));
        assertFalse(validator.isValidPhoneNumber(""));
        assertFalse(validator.isValidPhoneNumber(null));
    }

    @Test
    void testEmail() {
        assertTrue(validator.isValidEmail("test@example.com"));
        assertTrue(validator.isValidEmail("user123@test.co.kr"));

        assertFalse(validator.isValidEmail("dasfadsf"));
        assertFalse(validator.isValidEmail("@ttttt.com"));
        assertFalse(validator.isValidEmail("test@"));
        assertFalse(validator.isValidEmail(""));
        assertFalse(validator.isValidEmail(null));
    }

    @Test
    void testNormalizePhoneNumber() {
        assertEquals("01012341234", validator.normalizePhoneNumber("010-1234-1234"));
        assertEquals("01011112222", validator.normalizePhoneNumber("010-1111-2222"));
        assertEquals("01012341234", validator.normalizePhoneNumber("01012341234"));
    }
}
