package com.hyundai.test.address.controller;

import com.hyundai.test.address.model.Customer;
import com.hyundai.test.address.model.SearchFilter;
import com.hyundai.test.address.model.UpdateResponse;
import com.hyundai.test.address.service.AddressBookService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class AddressBookController {

    private final AddressBookService service;

    public AddressBookController(AddressBookService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<Customer>> searchCustomers(
            @RequestParam(required = false) String phoneNumber,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String address,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String sortOrder) {

        SearchFilter filter = new SearchFilter(phoneNumber, email, address, name, sortBy, sortOrder);
        List<Customer> customers = service.searchCustomers(filter);
        return ResponseEntity.ok(customers);
    }

    @PutMapping
    public ResponseEntity<UpdateResponse> updateCustomer(@RequestBody Customer customer) {
        UpdateResponse response = service.updateCustomer(customer);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping
    public ResponseEntity<List<Customer>> deleteCustomers(
            @RequestParam(required = false) String phoneNumber,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String address,
            @RequestParam(required = false) String name) {

        SearchFilter filter = new SearchFilter(phoneNumber, email, address, name, null, null);
        List<Customer> deleted = service.deleteCustomers(filter);
        return ResponseEntity.ok(deleted);
    }
}
