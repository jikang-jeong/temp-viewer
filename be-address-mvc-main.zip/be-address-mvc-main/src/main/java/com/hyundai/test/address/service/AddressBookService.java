package com.hyundai.test.address.service;

import com.hyundai.test.address.model.Customer;
import com.hyundai.test.address.model.SearchFilter;
import com.hyundai.test.address.model.UpdateResponse;
import com.hyundai.test.address.repository.AddressBookRepository;
import com.hyundai.test.address.validator.CustomerValidator;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class AddressBookService {

    private final AddressBookRepository repository;
    private final CustomerValidator validator;

    public AddressBookService(AddressBookRepository repository, CustomerValidator validator) {
        this.repository = repository;
        this.validator = validator;
    }

    public List<Customer> searchCustomers(SearchFilter filter) {
        return repository.findAll(filter);
    }

    public UpdateResponse updateCustomer(Customer customer) {
        validateCustomer(customer);

        Customer before = repository.update(customer);
        Customer after = repository.findByPhoneNumber(customer.getPhoneNumber());

        return new UpdateResponse(before, after);
    }

    public List<Customer> deleteCustomers(SearchFilter filter) {
        if (isEmpty(filter)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제할 조건을 지정해주세요");
        }
        return repository.delete(filter);
    }

    private void validateCustomer(Customer customer) {
        if (customer == null || customer.getPhoneNumber() == null || customer.getPhoneNumber().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "전화번호는 필수입니다");
        }
        if (!validator.isValidPhoneNumber(customer.getPhoneNumber())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "전화번호 형식이 올바르지 않습니다: " + customer.getPhoneNumber());
        }
        if (customer.getEmail() != null && !customer.getEmail().isEmpty()
                && !validator.isValidEmail(customer.getEmail())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "이메일 형식이 올바르지 않습니다: " + customer.getEmail());
        }

        customer.setPhoneNumber(validator.normalizePhoneNumber(customer.getPhoneNumber()));
    }

    private boolean isEmpty(SearchFilter filter) {
        if (filter == null) return true;
        return (filter.getPhoneNumber() == null || filter.getPhoneNumber().isEmpty()) &&
               (filter.getEmail() == null || filter.getEmail().isEmpty()) &&
               (filter.getAddress() == null || filter.getAddress().isEmpty()) &&
               (filter.getName() == null || filter.getName().isEmpty());
    }
}
