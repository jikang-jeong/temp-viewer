package com.hyundai.test.address.model;

public class UpdateResponse {
    private Customer before;
    private Customer after;

    public UpdateResponse() {
    }

    public UpdateResponse(Customer before, Customer after) {
        this.before = before;
        this.after = after;
    }

    public Customer getBefore() {
        return before;
    }

    public void setBefore(Customer before) {
        this.before = before;
    }

    public Customer getAfter() {
        return after;
    }

    public void setAfter(Customer after) {
        this.after = after;
    }
}
