package com.hyundai.test.address.validator;

import org.springframework.stereotype.Component;

/*
 - 전화번호는 010으로 시작해야 합니다.
 - 전화번호 형식은 0101231234 또는 010-123-1234 또는 010-1234-1234 이어야 합니다.
 - 이메일 형식은 아이디@도메인 이어야 합니다.
 */
@Component
public class CustomerValidator {

    public boolean isValidPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return false;
        }

        if (!phoneNumber.startsWith("010")) {
            return false;
        }

        if (phoneNumber.contains("-")) {
            String[] parts = phoneNumber.split("-");
            if (parts.length != 3) return false;
            if (!parts[0].equals("010")) return false;
            if (parts[1].length() < 3 || parts[1].length() > 4) return false;
            if (parts[2].length() != 4) return false;
            if (!isDigits(parts[1]) || !isDigits(parts[2])) return false;
        } else {
            if (phoneNumber.length() != 10 && phoneNumber.length() != 11) return false;
            if (!isDigits(phoneNumber)) return false;
        }

        return true;
    }

    public boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }

        if (!email.contains("@") || email.startsWith("@") || email.endsWith("@")) {
            return false;
        }

        return true;
    }

    public String normalizePhoneNumber(String phoneNumber) {
        return phoneNumber.replaceAll("-", "");
    }

    private boolean isDigits(String str) {
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }
}
