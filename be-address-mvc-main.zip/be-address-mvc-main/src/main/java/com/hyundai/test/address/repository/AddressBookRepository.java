package com.hyundai.test.address.repository;

import com.hyundai.test.address.common.CsvFileReader;
import com.hyundai.test.address.model.Customer;
import com.hyundai.test.address.model.SearchFilter;
import com.hyundai.test.address.validator.CustomerValidator;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.web.server.ResponseStatusException;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/*
- 데이터의 키는 전화번호입니다.
- 이메일은 중복될 수 없습니다.
- 메모리에 데이터를 로딩할 때 형식을 만족하지 못하는 경우 *****Warning 로그*****를 작성한 뒤 skip
- 모든 코드를 동시성 문제와 성능을 고려하여 작성
- 어플리케이션을 중지할 때 기존 파일은 ******백업*******하고 메모리에 로딩되어 있는 내용으로 저장
 */
@Repository
public class AddressBookRepository {

    private static final Logger logger = LoggerFactory.getLogger(AddressBookRepository.class);

    private final Map<String, Customer> customers = new ConcurrentHashMap<>();
    private final Map<String, String> emailToPhone = new ConcurrentHashMap<>();

    private final CustomerValidator validator;
    private final CsvFileReader csvReader;

    @Value("${address.data.file:default_address.csv}")
    private String filePath;

    public AddressBookRepository(CustomerValidator validator) {
        this.validator = validator;
        this.csvReader = new CsvFileReader();
    }

    @PostConstruct
    public void init() {
        logger.info("****** 데이터 로딩 시작: {}", filePath);
        loadFromFile();
        logger.info("****** 데이터 로딩 완료: {}건", customers.size());
    }

    @PreDestroy
    public void destroy() {
        logger.info("****** 애플리케이션 종료 - 데이터 저장");
        try {
            saveToFile();
        } catch (IOException e) {
            logger.error("****** 데이터 저장 실패", e);
        }
    }

    private void loadFromFile() {
        try {
            List<String> lines;

            // 파일시스템에 먼저 확인 (이전 종료 시 저장한 파일이 있을 수 있음)
            Path path = Paths.get(filePath);
            if (Files.exists(path)) {
                lines = Files.readAllLines(path);
                logger.info("****** 파일시스템에서 로드: {}", path.toAbsolutePath());
            } else {
                lines = csvReader.read(filePath);
                logger.info("****** classpath에서 로드: {}", filePath);
            }

            for (int i = 1; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                String[] parts = line.split(",");
                if (parts.length != 4) {
                    logger.warn("****** 라인 {}: 필드 수 불일치", i + 1);
                    continue;
                }

                String address = parts[0].trim();
                String phone = parts[1].trim();
                String email = parts[2].trim();
                String name = parts[3].trim();

                if (!validator.isValidPhoneNumber(phone)) {
                    logger.warn("****** 라인 {}: 전화번호 형식 오류 - {}", i + 1, phone);
                    continue;
                }
                if (!validator.isValidEmail(email)) {
                    logger.warn("****** 라인 {}: 이메일 형식 오류 - {}", i + 1, email);
                    continue;
                }

                String normalizedPhone = validator.normalizePhoneNumber(phone);

                if (customers.containsKey(normalizedPhone)) {
                    logger.warn("****** 라인 {}: 중복 전화번호 - {}", i + 1, normalizedPhone);
                    continue;
                }
                if (emailToPhone.containsKey(email)) {
                    logger.warn("****** 라인 {}: 중복 이메일 - {}", i + 1, email);
                    continue;
                }

                Customer customer = new Customer(normalizedPhone, email, address, name);
                customers.put(normalizedPhone, customer);
                emailToPhone.put(email, normalizedPhone);
            }
        } catch (IOException e) {
            logger.error("****** 파일 읽기 실패", e);
        }
    }

    private void saveToFile() throws IOException {
        Path path = Paths.get(filePath);

        // 기존 파일 백업
        if (Files.exists(path)) {
            String timeStamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String name = filePath.replace(".csv", "");
            Path backupPath = Paths.get(name + "_" + timeStamp + ".csv");
            Files.copy(path, backupPath, StandardCopyOption.REPLACE_EXISTING);
            logger.info("****** 백업 생성: {}", backupPath);
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("\"주소\",\"연락처\",\"이메일\",\"이름\"");
            writer.newLine();
            for (Customer c : customers.values()) {
                writer.write(String.format("%s,%s,%s,%s",
                        c.getAddress(), c.getPhoneNumber(), c.getEmail(), c.getName()));
                writer.newLine();
            }
        }
        logger.info("****** 데이터 저장 완료: {}건", customers.size());
    }

    public List<Customer> findAll(SearchFilter filter) {
        return customers.values().stream()
                .filter(c -> matches(c, filter))
                .sorted(getComparator(filter))
                .map(Customer::copy)
                .collect(Collectors.toList());
    }

    // 이메일 변경 시 중복체크가 포함되므로 동기화 필요
    public synchronized Customer update(Customer customer) {
        String phone = validator.normalizePhoneNumber(customer.getPhoneNumber());

        Customer existing = customers.get(phone);
        if (existing == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "고객을 찾을 수 없습니다: " + phone);
        }

        if (!existing.getEmail().equals(customer.getEmail())) {
            if (emailToPhone.containsKey(customer.getEmail())) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "이미 사용 중인 이메일입니다: " + customer.getEmail());
            }
            emailToPhone.remove(existing.getEmail());
            emailToPhone.put(customer.getEmail(), phone);
        }

        Customer old = existing.copy();
        existing.setEmail(customer.getEmail());
        existing.setAddress(customer.getAddress());
        existing.setName(customer.getName());

        return old;
    }

    public synchronized List<Customer> delete(SearchFilter filter) {
        List<Customer> toDelete = customers.values().stream()
                .filter(c -> matches(c, filter))
                .map(Customer::copy)
                .collect(Collectors.toList());

        if (toDelete.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "삭제할 고객을 찾을 수 없습니다");
        }

        for (Customer c : toDelete) {
            customers.remove(c.getPhoneNumber());
            emailToPhone.remove(c.getEmail());
        }

        return toDelete;
    }

    public Customer findByPhoneNumber(String phone) {
        String normalized = validator.normalizePhoneNumber(phone);
        Customer c = customers.get(normalized);
        return c != null ? c.copy() : null;
    }

    public int count() {
        return customers.size();
    }

    public void clear() {
        customers.clear();
        emailToPhone.clear();
    }

    private boolean matches(Customer c, SearchFilter f) {
        if (f == null) return true;

        if (f.getPhoneNumber() != null && !f.getPhoneNumber().isEmpty()) {
            String normalized = validator.normalizePhoneNumber(f.getPhoneNumber());
            if (!c.getPhoneNumber().equals(normalized)) return false;
        }
        if (f.getEmail() != null && !f.getEmail().isEmpty()) {
            if (!c.getEmail().equals(f.getEmail())) return false;
        }
        if (f.getName() != null && !f.getName().isEmpty()) {
            if (!c.getName().contains(f.getName())) return false;
        }
        if (f.getAddress() != null && !f.getAddress().isEmpty()) {
            if (!c.getAddress().contains(f.getAddress())) return false;
        }

        return true;
    }

    private Comparator<Customer> getComparator(SearchFilter f) {
        if (f == null || f.getSortBy() == null) {
            return Comparator.comparing(Customer::getPhoneNumber);
        }

        Comparator<Customer> comp;
        switch (f.getSortBy().toUpperCase()) {
            case "EMAIL": comp = Comparator.comparing(Customer::getEmail); break;
            case "ADDRESS": comp = Comparator.comparing(Customer::getAddress); break;
            case "NAME": comp = Comparator.comparing(Customer::getName); break;
            default: comp = Comparator.comparing(Customer::getPhoneNumber);
        }

        if ("DESC".equalsIgnoreCase(f.getSortOrder())) {
            comp = comp.reversed();
        }

        return comp;
    }
}
