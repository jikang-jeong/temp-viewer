package com.hyundai.test.address.model;

public class Customer {
    private String phoneNumber;  // 키 (Primary Key)
    private String email;
    private String address;
    private String name;

    public Customer() {
    }

    public Customer(String phoneNumber, String email, String address, String name) {
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.address = address;
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Customer copy() {
        return new Customer(this.phoneNumber, this.email, this.address, this.name);
    }

    @Override
    public String toString() {
        return "Customer{" +
                "phoneNumber='" + phoneNumber + '\'' +
                ", email='" + email + '\'' +
                ", address='" + address + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
